
var firstNumber = 24;
var secondNumber = 15;

var sum = firstNumber + secondNumber;

alert("Addition result: " + sum);
