var firstNumber = 24;
var secondNumber = 15;

var multiplicationResult = firstNumber * secondNumber;

alert("Multiplication result: " + multiplicationResult);
